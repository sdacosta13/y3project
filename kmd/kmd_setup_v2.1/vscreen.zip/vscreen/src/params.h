#define SCREEN_WIDTH_MAX  1280
#define SCREEN_HEIGHT_MAX  960
#define SCREEN_WIDTH_MIN   200	// Intended to ensure buttons are drawn
#define SCREEN_WIDTH_LABEL 400	// Above this size, add text labels to buttons

#define FRAME_WIDTH_MAX   1280
#define FRAME_HEIGHT_MAX   960

#define SCREEN_NC            3	// Always just RGB

// Default parameters
#define FRAME_WIDTH   640	// Dimensions of the 'real' image
#define FRAME_HEIGHT  480

#define R_DEPTH         8
#define G_DEPTH         8
#define B_DEPTH         8

#define ASPECT_WIDTH    4
#define ASPECT_HEIGHT   3

//#define SHM_KEY       (-1)	// -1 for 'undefined'
#define SHM_KEY       234

#define HNDSHK_LED        0x20
#define HNDSHK_IMG_ACK    0x80
#define HNDSHK_IMG_REQ    0x40
#define HNDSHK_NEW_IMAGE  0x01
