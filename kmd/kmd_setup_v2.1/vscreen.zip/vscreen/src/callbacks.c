#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <signal.h>

#include "params.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "globals.h"

/*----------------------------------------------------------------------------*/
/* Load Image                                                                 */

void load_image (GtkButton *button, gpointer user_data)
{
GtkWidget       *dialog;
GdkPixbufFormat *format;
GdkPixbuf       *image_pixbuf;

GtkWidget       *edial;

char   *filename;
guchar *ipix;
guchar *fpix;
guint   width;
guint   height;
guint   line;
guint   col;

guint   fp;
guint   ip;
guint   row_start;
guint   inc;

guint   i;
guint   pixel;


dialog = gtk_file_chooser_dialog_new ("Load Image",
                                      (GtkWindow*)lookup_widget((GtkWidget*)button, "window1"),
                                       GTK_FILE_CHOOSER_ACTION_OPEN,
                                       GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                       GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
                                       NULL);

if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
  {
  filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
  format = gdk_pixbuf_get_file_info (filename, NULL, NULL);
  if (format == NULL)
    {
    edial = create_dialog1 (_("Error"),
                            _("Load Image failed:\nCannot open image file."));
    gtk_dialog_run (GTK_DIALOG (edial));
    gtk_widget_destroy (edial);
    }
  else
    {
    image_pixbuf = gdk_pixbuf_new_from_file_at_size (filename,
                                        frame_width, frame_height, NULL);
    if (image_pixbuf == NULL)
      {
      edial = create_dialog1 (_("Error"),
                              _("Load Image failed:\nCannot create image buffer."));
      gtk_dialog_run (GTK_DIALOG (edial));
      gtk_widget_destroy (edial);
      }
    else
      {                                  /* Copy image buffer to frame buffer */
      width  = MIN(gdk_pixbuf_get_width (image_pixbuf), frame_width);
      height = MIN(gdk_pixbuf_get_height(image_pixbuf), frame_height);
      ipix = gdk_pixbuf_get_pixels(image_pixbuf);
      inc  = gdk_pixbuf_get_n_channels(image_pixbuf);
      fpix = shm;				// @@@
      row_start = 0;
      fp = 0;
      for (line = 0; line < height; line++)
        {
        ip = row_start;
        for (col = 0; col < width; col++)
          {
          pixel = pixel_pack(&ipix[ip]);
          ip += inc;
          for (i = 0; i < pixel_bytes; i++)          /* Output pixel as bytes */
            {
            fpix[fp++] = pixel & 0xFF;
            pixel = pixel >> 8;
            }
          }
        fp = fp + (frame_width - width) * pixel_bytes;
                              /* Add stride in case frame is wider than image */
        row_start += gdk_pixbuf_get_rowstride(image_pixbuf);
             /* Rows not guaranteed contiguous (e.g. they start word aligned) */
        }

      refresh_pixels(fpix, screen_pixbuf, scale); /* Refresh window from fpix */

      g_object_unref (image_pixbuf);

      gtk_statusbar_pop (statusBar, 1);                   /* clear status bar */

      *hndshk |= (guchar)HNDSHK_IMG_ACK;        /* report new image to caller */
      }
    }
  g_free (filename);
  }

gtk_widget_destroy (dialog);

return;
}

/*----------------------------------------------------------------------------*/
/* Save Image                                                                 */

void save_image (GtkButton *button, gpointer user_data)
{
    GtkWidget *dialog;

    /* open dialog to choose image file */
    dialog = gtk_file_chooser_dialog_new ("Save Image",
                                          (GtkWindow*)lookup_widget((GtkWidget*)button, "window1"),
                                           GTK_FILE_CHOOSER_ACTION_SAVE,
                                           GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                           GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
                                           NULL);
    gtk_file_chooser_set_current_name (GTK_FILE_CHOOSER (dialog), "screenDump.png");

    /* Save image from pixbuf */
    if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
    {
        char *filename;
        GdkPixbuf *save_buffer;
        guchar *psave;
//      guint i;

        filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
        /* Copy raw frame into saveable structure */
        save_buffer = gdk_pixbuf_new(GDK_COLORSPACE_RGB, FALSE, 8,
                                     frame_width, frame_height);
        psave = gdk_pixbuf_get_pixels(save_buffer);

        pixel_copy(shm, psave, frame_width, 1);  /* Colour transform to 8:8:8 */

        gdk_pixbuf_save(save_buffer, filename, "png", NULL, NULL);

        g_object_unref(save_buffer);
        g_free (filename);
    }

    gtk_widget_destroy (dialog);
}

/*----------------------------------------------------------------------------*/
/* Save Image JDG special                                                     */
/*  Dump as assembler source */

// 448 x 336 is 4 x 3 image with 147 Kpixels
//#define X_SIZE 448
//#define Y_SIZE 336
#define X_SIZE 320
#define Y_SIZE 240

#define RED    0
#define GREEN  1
#define BLUE   2
#define OFFSET ((x + frame_width*y) * pixel_bytes)

void plop (GtkButton *button, gpointer user_data)
{
    GtkWidget *dialog;
    FILE      *f_image;

    /* open dialogue to choose image file */
    dialog = gtk_file_chooser_dialog_new ("Save Image",
                                          (GtkWindow*)lookup_widget((GtkWidget*)button, "window1"),
                                           GTK_FILE_CHOOSER_ACTION_SAVE,
                                           GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                           GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
                                           NULL);
    gtk_file_chooser_set_current_name (GTK_FILE_CHOOSER (dialog), "ScreenDump.s");

    /* Save image from pixbuf */
    if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
    {
        char *filename;
        GdkPixbuf *save_buffer;
        guchar *psave;
	guint   x, y, temp;
	guint   pixel;

        filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));

	f_image = fopen(filename, "w");
	if (f_image != NULL)
	  {

	    /* Copy raw frame into saveable structure */
	    save_buffer = gdk_pixbuf_new(GDK_COLORSPACE_RGB, FALSE, 8,
					 frame_width, frame_height);
	    psave = gdk_pixbuf_get_pixels(save_buffer);

	    pixel_copy(shm, psave, frame_width, 1);  /* Colour transform to 8:8:8 */

            for (y = 0; y < Y_SIZE; y++)
	      {
		fprintf(f_image, "\n; Row %3d", y);
                for (x = 0; x < X_SIZE; x++)
		  {
		    if (x % 8 == 0) fprintf(f_image, "\n\t\tdefb\t");
		    else            fprintf(f_image, ", ");

/*		    pixel = (((guint)psave[OFFSET + RED  ] + 0x10) & 0xE0) |
                         ((((guint)psave[OFFSET + GREEN] + 0x10) >> 3) & 0x1C) |
                         ((((guint)psave[OFFSET + BLUE ] + 0x20) >> 6) & 0x03);
*/

		    temp = ((guint)psave[OFFSET + RED  ]) + 0x10;
                    if ((temp & 0x100) != 0) temp = 0xFF;	// Saturate
		    pixel = temp & 0xE0;
		    temp = ((guint)psave[OFFSET + GREEN]) + 0x10;
                    if ((temp & 0x100) != 0) temp = 0xFF;	// Saturate
		    pixel |= (temp >> 3) & 0x1C;
		    temp = ((guint)psave[OFFSET + BLUE ]) + 0x20;
                    if ((temp & 0x100) != 0) temp = 0xFF;	// Saturate
		    pixel |= (temp >> 6) & 0x03;

		    fprintf(f_image, "&%02X", pixel);
		  }
	      }

	    fprintf(f_image, "\n");
	    fclose(f_image);
	    g_object_unref(save_buffer);
	  }

        g_free (filename);
    }

    gtk_widget_destroy (dialog);
}

// - - - - - - - - - - - - - - - -

void plop2 (GtkButton *button, gpointer user_data)
{
    GtkWidget *dialog;

    /* open dialogue to choose image file */
    dialog = gtk_file_chooser_dialog_new ("Save Image",
                                          (GtkWindow*)lookup_widget((GtkWidget*)button, "window1"),
                                           GTK_FILE_CHOOSER_ACTION_SAVE,
                                           GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                           GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
                                           NULL);
    gtk_file_chooser_set_current_name (GTK_FILE_CHOOSER (dialog), "ScreenDump.s");

    /* Save image from shm */
    if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
      {
      char *filename, *pChar;
      FILE *f_image;
      guint   x, y;
      gboolean verilog;

      filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));

      pChar = filename;
      while (*pChar != '\0') pChar++; pChar--;
      verilog = ((*pChar | 0x20) == 'v');	// Look at last character

      f_image = fopen(filename, "w");
      if (f_image != NULL)
        {
        for (y = 0; y < frame_height; y++)
          {
          if (verilog)
            {
            fprintf(f_image, "\n// Row %3d", y);
            fprintf(f_image, "\n@%06X", 640*y);
	    }
          else
            fprintf(f_image, "\n; Row %3d", y);

          for (x = 0; x < frame_width; x++)
            {
            if (verilog) fprintf(f_image, "\n%02X", shm[(x + frame_width*y)]);
	    else
	      {
              if (x % 8 == 0) fprintf(f_image, "\n\t\tdefb\t");
              else            fprintf(f_image, ", ");
              fprintf(f_image, "&%02X", shm[(x + frame_width*y)]);
	      }
            }
          }

        fprintf(f_image, "\n");
        fclose(f_image);
        }

      g_free (filename);
      }

    gtk_widget_destroy (dialog);
}

/*----------------------------------------------------------------------------*/
/* Blank                                                                      */

void blank (GtkButton *button, gpointer user_data)
{
    guint padr, i;

    /* Write 'BLACK' to all pixbuf locations */
    for (padr = 0; padr < frame_width*frame_height*pixel_bytes; padr++)
        shm[padr] = (guchar)0;
    *hndshk = 0;

    /* refresh window from pixb */
    refresh_pixels(shm, screen_pixbuf, scale);

    /* Turn off all LEDs */
    for (padr = 0; padr < No_LEDs; padr++)
      gtk_image_set_from_stock (led[padr], "gtk-no", GTK_ICON_SIZE_BUTTON);
    if (No_LEDs != 0) *ledshm = 0;
}

/*----------------------------------------------------------------------------*/
/* Work in progress ...  @@@@                                                 */

void save_file (GtkButton *button, gpointer user_data)
{
    GtkWidget *dialog;
    FILE      *output_file;
    guint      x, y, k;
    guint      pixel;
    guchar     rgb[SCREEN_NC];
    gboolean   blank;

    /* open dialog to choose image file */
    dialog = gtk_file_chooser_dialog_new ("Save File",
                                          (GtkWindow*)lookup_widget((GtkWidget*)button,
                                                                     "window1"),
                                           GTK_FILE_CHOOSER_ACTION_SAVE,
                                           GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                           GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
                                           NULL);
    gtk_file_chooser_set_current_name (GTK_FILE_CHOOSER (dialog), "file.txt");

    /* Save text file */
    if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
    {
        char *filename;

        filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
        output_file = fopen(filename, "w");

        blank = TRUE;
        for (y = 0; y < frame_height; y++)
          for (x = 0; x < frame_width; x++)
            {
            pixel = 0;
            for (k = 0; k < pixel_bytes; k++)               /* Assemble pixel */
              pixel |= shm[(x + frame_width*y) * pixel_bytes + k] << (8*k);

            if (pixel != 0)
              {
              if (blank)                                /* Print header, once */
                {
//              fprintf(output_file, "    X    Y    R   G   B\n");
                fprintf(output_file, "    X    Y   R%%  G%%  B%%\n");
                blank = FALSE;
                }
              pixel_unpack(pixel, rgb);
              rgb[0] = (pixel >> (g_depth +  b_depth)) & ((1 << r_depth) - 1);
              rgb[1] = (pixel >>  b_depth)             & ((1 << g_depth) - 1);
              rgb[2] =  pixel                          & ((1 << b_depth) - 1);
//            fprintf(output_file,"%5d%5d %4d%4d%4d\n",x,y,rgb[0],rgb[1],rgb[2]);
              {
              float rr, gg, bb;
              rr = 100.0 * rgb[0]/((1 << r_depth) - 1);
              gg = 100.0 * rgb[1]/((1 << g_depth) - 1);
              bb = 100.0 * rgb[2]/((1 << b_depth) - 1);
              fprintf(output_file,"%5d%5d %4.0f%4.0f%4.0f\n", x, y, rr, gg, bb);
              }
              }
            }

        if (blank) fprintf(output_file, "The screen is blank.\n");

        fclose(output_file);
        g_free (filename);
    }

    gtk_widget_destroy (dialog);
}

/*----------------------------------------------------------------------------*/

void
on_window1_destroy                     (GtkObject       *object,
                                        gpointer         user_data)
{
    gtk_main_quit();
    return;
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */

void quit (GtkButton *button, gpointer user_data)
{
    gtk_main_quit();
    return;
}

/*----------------------------------------------------------------------------*/

gboolean
on_drawingarea1_expose_event           (GtkWidget       *widget,
                                        GdkEventExpose  *event,
                                        gpointer         user_data)
{
    /* refresh window from shm */
  refresh_pixels(shm, screen_pixbuf, scale);
  return FALSE;
}

/*----------------------------------------------------------------------------*/

guchar* create_shm()
{
key_t key;
guchar *shm;
gint i, j;

/*   Create or link to the shared memory buffer that is used as frame store   */
if (shm_key == -1)                    /* No key specified - try to create one */
  {
  guint i;
  for (shmid = -1, i = 0; (shmid == -1) && (i < 10); i++)	// 10 tries
    {					// Seed rand for better performance @@@
    key = (key_t)(rand() & 0x7FFFFFFF);
    shmid = shmget(key, shm_sz, IPC_CREAT | IPC_EXCL | 0666);
    }

  if (shmid != -1)
    {
    shm_owner = TRUE;                                         /* Created here */
    shm_key = (guint)key;                  /* Keep the randomly generated key */
    }
  }
else                       /* Key specified create it if not there, else link */
  {
  key = (key_t)shm_key;   /* Segment ID to be used by other frame store users */
  shmid = shmget(key, shm_sz, IPC_CREAT | IPC_EXCL | 0666);
  if (shmid != -1) shm_owner = TRUE;                          /* Created here */
  else                                /* Try again but pick up existing store */
    shmid = shmget(key, shm_sz, IPC_CREAT | 0666);
  }

if (shmid == -1)              /* Abject failure to sort out the shared memory */
  {
  perror("vscreen: ERROR - cannot create shared memory");
  exit(1);
  }

/* Attach the segment to local data space */
if ((shm = (guchar *) shmat(shmid, NULL, 0)) == (guchar *) -1)
  {
  perror("vscreen: ERROR - cannot attach shared memory");
  if (shm_owner)         /* Schedule the shared memory buffer for destruction */
    if (shmctl(shmid, IPC_RMID, NULL) < 0)
      perror("vscreen: ERROR - cannot destroy shared memory");
  exit(1);
  }

/* Initialise memory with random pixels */
for (i = 0; i < frame_width*frame_height*pixel_bytes; i++)
  shm[i] = rand() & 0xFF;

hndshk = &shm[frame_sz];      /* Setup the handshake pointer in shared memory */
ledshm = &shm[frame_sz + 1];        /* Setup the LED pointer in shared memory */

*hndshk = 0;                                      /* Clear the handshake byte */
*ledshm = 0;                                           /* Clear the LEDs byte */

/* Let parent process know that the shared buffer is setup */
kill (getppid (), SIGCONT);
return(shm);
}

/*----------------------------------------------------------------------------*/

void release_shm(guchar *shm, gint shmid, gboolean shm_owner)
{
    /* detach the shared memory buffer */
    if (shmdt(shm) < 0) {
        perror("vscreen: ERROR - cannot release shared memory");
        exit(1);
    }

    if (shm_owner)
        /* schedule the shared memory buffer for destruction */
        if (shmctl(shmid, IPC_RMID, NULL) < 0) {
            perror("vscreen: ERROR - cannot destroy shared memory");
            exit(1);
        }
}

/*----------------------------------------------------------------------------*/
/* Unpack framestore into pixbuf-style array                                  */

void pixel_copy(guchar *frame_buffer, guchar *screen_buffer, guint sw, guint scale)
{
guint   x, y, i, j, k;
guint   pixel;
guchar  rgb[SCREEN_NC];

for (y = 0; y < frame_height; y++)           /* Copy/expand 'frame' to screen */
  for (x = 0; x < frame_width; x++)
    {
    pixel = 0;
    for (k = 0; k < pixel_bytes; k++)                       /* Assemble pixel */
      pixel |= frame_buffer[(x + frame_width*y) * pixel_bytes + k] << (8*k);
    pixel_unpack(pixel, rgb);               /* Expand to three 8-bit channels */

    for (j = 0; j < scale; j++)                      /* Scan over screen area */
      for (i = 0; i < scale; i++)
        {
        for (k = 0; k < SCREEN_NC; k++)                        /* For colours */
          screen_buffer[((x*scale+i) + sw*(y*scale+j)) * SCREEN_NC + k] = rgb[k];
        }
    }

return;
}

/*----------------------------------------------------------------------------*/
/* Refresh window from source                                                 */

void refresh_pixels(guchar *frame_buffer, GdkPixbuf *screen_pixbuf, guint scale)
{
guchar *screen_buffer;
guint   sw;

screen_buffer = gdk_pixbuf_get_pixels(screen_pixbuf);
sw = gdk_pixbuf_get_width(screen_pixbuf);            /* Saves querying global */

pixel_copy(frame_buffer, screen_buffer, sw, scale);   /* Copy/scale to buffer */

gdk_draw_pixbuf (drawingArea->window,
                 drawingArea->style->fg_gc[GTK_WIDGET_STATE (drawingArea)],
                 screen_pixbuf, 0, 0, 0, 0, -1, -1,
                 GDK_RGB_DITHER_NONE, 0, 0);
return;
}

/*----------------------------------------------------------------------------*/
/* Pack RGB into desired pixel representation                                 */

guint pixel_pack(guchar* rgb)
{
guchar  r, g, b;
guint   bw;
guint   pixel;

if (monochrome == 0)
  {
  r = colour_scale(rgb[0], 8, r_depth);
  g = colour_scale(rgb[1], 8, g_depth);
  b = colour_scale(rgb[2], 8, b_depth);
  pixel = (((r << g_depth) | g) << b_depth) | b;
  }
else
  {
  bw = rgb[0] + rgb[1] + rgb[2];	// Wants to scale colours differently! @@@
  bw = ((2*bw) + 1) / 6;
  pixel = colour_scale(bw, 8, monochrome);
  }

return pixel;
}

/*----------------------------------------------------------------------------*/
/* Unpack pixel into RGB array                                                */

void pixel_unpack(guint pixel, guchar *rgb)
{
if (monochrome == 0)
  {
  rgb[0] = colour_scale(pixel >> (g_depth +  b_depth), r_depth, 8);
  rgb[1] = colour_scale(pixel >>  b_depth,             g_depth, 8);
  rgb[2] = colour_scale(pixel,                         b_depth, 8);
  }
else
  {
  rgb[0] = colour_scale(pixel, monochrome, 8);
  rgb[1] = rgb[0];
  rgb[2] = rgb[0];
  }
return;
}

/*----------------------------------------------------------------------------*/
/* Convert colour from m to n bit representation                              */

guint colour_scale(guint colour, guint m, guint n)
{
gint i;
guint x;

colour = colour & ((1 << m) - 1);                               /* Mask input */

if (m == n) x = colour;
else
  if (m > n)                                             /* Reduce resolution */
    {                               /* ( colour * (2^n - 1) + 2^(m-1) ) / 2^m */
    x = (colour * ((1<<n)-1) + (1<<(m-1))) >> m;
    }
  else                                                        /* Expand range */
    {                            /* Repeat smaller pattern in larger from MSB */
    x = 0;
    for (i = n - m; i > 0; i -= m) x |= colour << i;
    x |= colour >> (-i);
    }
return x;
}

/*----------------------------------------------------------------------------*/

gboolean update_screen(gpointer data) {
    guint i;
    guint mask;

    /* check that parent process is still alive */
    if (clrPid != getppid()) {
        gtk_main_quit();
        return;
    }

    /* if needed, refresh window from shm */
    if ((refresh_time > 0) || ((*hndshk & HNDSHK_NEW_IMAGE) != 0)) {
        /* turn handshake off before refresh to avoid race with caller */
        *hndshk &= ~HNDSHK_NEW_IMAGE;
        refresh_pixels(shm, screen_pixbuf, scale);
    }

    /* IF needed, update LEDs */
    if (No_LEDs != 0)
        {
	  if ((refresh_time > 0) || ((*hndshk & HNDSHK_LED) != 0)) {
            /* turn handshake off before led update to avoid race with caller */
            *hndshk &= ~HNDSHK_LED;
            for (i = 0, mask = 1; i < No_LEDs; i++) {
              if ((*ledshm & mask) == 0)
                  gtk_image_set_from_stock (led[i], "gtk-no", GTK_ICON_SIZE_BUTTON);
              else
                  gtk_image_set_from_stock (led[i], "gtk-yes", GTK_ICON_SIZE_BUTTON);
                mask = mask << 1;
            }
        }
        }

    /* if needed, request new image from the user */
    if ((*hndshk & HNDSHK_IMG_REQ) != 0) {
        gtk_statusbar_push (statusBar, 1, "New request: LOAD IMAGE");
        *hndshk &= ~HNDSHK_IMG_REQ;
    }

    return TRUE;
}

/*============================================================================*/
