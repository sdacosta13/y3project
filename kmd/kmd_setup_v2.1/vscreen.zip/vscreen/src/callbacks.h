#include <gtk/gtk.h>

#ifndef CALLBK_H
#define CALLBK_H

#include "params.h"

/* GLOBAL: parent process id */
pid_t clrPid;

GtkWidget    *drawingArea;
GtkStatusbar *statusBar;
GdkPixbuf    *screen_pixbuf;

GtkImage     *led[8];

gint    shmid;
guchar *shm;
guchar *hndshk;
guchar *ledshm;

void load_image (GtkButton *button, gpointer user_data);
void save_image (GtkButton *button, gpointer user_data);
void plop       (GtkButton *button, gpointer user_data);
void plop2      (GtkButton *button, gpointer user_data);
void blank      (GtkButton *button, gpointer user_data);
void save_file  (GtkButton *button, gpointer user_data);
void quit       (GtkButton *button, gpointer user_data);

void on_window1_destroy (GtkObject *object, gpointer user_data);

gboolean
on_drawingarea1_expose_event           (GtkWidget       *widget,
                                        GdkEventExpose  *event,
                                        gpointer         user_data);

guchar* create_shm();
void    release_shm();

void pixel_copy(guchar*, guchar*, guint, guint);
void refresh_pixels(guchar*, GdkPixbuf*, guint);

guint pixel_pack(guchar*);
void  pixel_unpack(guint, guchar*);
guint colour_scale(guint, guint, guint);

gboolean update_screen(gpointer data);

gboolean refresh_screen(gpointer data);

#endif
