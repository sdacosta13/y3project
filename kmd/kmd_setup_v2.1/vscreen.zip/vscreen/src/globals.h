#include <gtk/gtk.h>

guint No_LEDs;

guint screen_width;
guint screen_height;

guchar *screen_buffer;		// Expansion buffer for magnified drawing

//guint image_width;
//guint image_height;
//guint image_nc;

guint r_depth;
guint g_depth;
guint b_depth;
guint monochrome;		// 0 for colour, else number of bits
guint pixel_bytes;

guint frame_width;
guint frame_height;
guint frame_nc;

guint frame_sz;
guint shm_sz;

gint scale;			// Allowed -1 as a 'default' indication

gint shm_key;			// Allowed -1 as a 'default' indication
gboolean shm_owner;

struct sigaction cleanup;

guint refresh_time;		// VDU 'unprompted' update rate

gboolean verbose;		// For debug purposes
