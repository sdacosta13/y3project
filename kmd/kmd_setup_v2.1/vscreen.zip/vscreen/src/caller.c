#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <signal.h>
#include <sys/wait.h>

#include "params.h"

/* GLOBAL: screen process ID */
pid_t scrPid;
char *pixbuf;
char  *shm;

uint frame_width;
uint frame_height;
uint frame_nc;
uint No_LEDs;
uint refresh_rate;


char* setup_shm(int *shmid, key_t key, uint shm_sz) {
    char *shm;

    /* locate the shared memory buffer that is used as frame store */
    if ((*shmid = shmget(key, shm_sz, 0666)) < 0) {
        perror("caller: ERROR - cannot locate shared memory.");
        exit(1);
    }
    /* attach the segment to local data space */
    if ((shm = shmat(*shmid, NULL, 0)) == (char *) -1) {
        perror("caller: ERROR - cannot attach shared memory.");
        exit(1);
    }
    return (shm);
}

void release_shm(char *shm) {
    /* detach the shared memory buffer that is used as frame store */
    if (shmdt(shm) < 0) {
        perror("caller: ERROR - cannot release shared memory.");
        exit(1);
    }
}

void draw_picture(char *shm, char *hndshk, char *ledshm) {
    int ip, fp;
    int line, col, chan;


    sleep(1);

    /* copy screen buffer to local buffer */
    ip = 0;
    fp = 0;
    for (line = 0; line < frame_height/2; line++) {
        for (col = 0; col < frame_width/2; col++) {
            for (chan = 0; chan < frame_nc; chan++) {
                pixbuf[fp++] = shm[ip++];
            }
            ip += frame_nc;		 // Skip alternate pixels
        }
        ip += frame_nc * frame_width;	 // Skip alternate lines
    }

    /* copy local buffer back to screen buffer */
    ip = 0;
    fp = 0;
    for (line = 0; line < frame_height/2; line++) {
        for (col = 0; col < frame_width/2; col++) {
            for (chan = 0; chan < frame_nc; chan++) {
                shm[ip++] = 255-pixbuf[fp++];
            }
        }
        ip += frame_nc * frame_width / 2;
    }

    /* report image ready */
    *hndshk &= ~HNDSHK_IMG_ACK;
    *hndshk |=  HNDSHK_NEW_IMAGE;

    /* write a new value to the LEDs */
    if (No_LEDs != 0) {*ledshm = 0x55; *hndshk |= HNDSHK_LED;}
					// Acknowledge omitted here @@@
}

void screen_synch (int sigNum) {
  int status;

    if (sigNum == SIGCONT) {
        /* once the screen has sent the SIGCONT signal we can */
        /* restore the signal handling to its default         */
        signal(SIGCONT, SIG_DFL);
    }
    else if (sigNum == SIGCHLD) {
	    /* check if vscreen terminated */
	    waitpid(scrPid, &status, (WNOHANG || WUNTRACED || WCONTINUED));
        if (!WIFCONTINUED(status) &&  !WIFSTOPPED(status)) {
            /* screen was closed -> terminate */
		    exit(0);
        }
    }
    else if (sigNum == SIGTERM) {
        /* release the shared memory buffer */
        release_shm(shm);
        /* terminate screen */
        kill (scrPid, SIGTERM);
        waitpid(scrPid, &status, 0);
        /* and terminate */
        exit(0);
    }
}

/*----------------------------------------------------------------------------*/

int main(int argc, char *argv[]) {
    int   shmid;
    char  *hndshk;
    char  *ledshm;
    int   i, j, k;
    int   status;
    char  swidth[7];                    /* Max. "-w" + 4 digits + terminator  */
    char  sheight[7];                   /* Max. "-h" + 4 digits + terminator  */
    char  sscale[5];                    /* Max. "-s" + 2 digits + terminator  */
    char  skey[13];                     /* Max. "-k" + 10 digits + terminator */
    char  sLEDs[4];                     /* "-l" + 1 digit + terminator        */
    char  srate[13];                    /* Max. "-r" + 10 digits + terminator */

    uint  frame_sz;
    uint  shm_sz;
    int   scale;			// Allowed -1 as a 'default' indication

frame_width  = 320;
frame_height = 240;
frame_nc     = 3;
scale        = 3;
No_LEDs      = 8;
refresh_rate = 100;                     // not used in this example! 

    /* Clip - also restricts length of strings passed as arguments */
    No_LEDs = No_LEDs >  8 ?  8 : No_LEDs;
    scale   = scale   > 16 ? 16 : scale;
    frame_width  = frame_width  > 1280 ? 1280 : frame_width;
    frame_height = frame_height >  960 ?  960 : frame_height;

    /* temporarily establish the SIGCONT signal */
    /* handler to synchronise with the screen   */
    signal(SIGCONT, screen_synch);
    /* establish the SIGCHLD signal     */
    /* handler to terminate with screen */
    signal(SIGCHLD, screen_synch);
    /* establish the SIGTERM signal */
    /* handler to terminate screen  */
    signal(SIGTERM, screen_synch);


   /* bring up the screen in a child process */
    scrPid = fork();
    if (scrPid == -1) {
        printf("caller: ERROR - cannot start 'screen'.\n");
        exit(1);
    }
    else if (scrPid == 0) {
        /* ------- the screen is the child process ------- */
        /* --- the screen updates from the frame store --- */
        nice(10);                    /* Reduce priority of the screen process */
        sprintf(skey,    "-k%d", SHM_KEY);    /* Make appropriate arg strings */
        sprintf(swidth,  "-w%d", frame_width);
        sprintf(sheight, "-h%d", frame_height);
        sprintf(sscale,  "-s%d", scale);
        sprintf(sLEDs,   "-l%d", No_LEDs);
        sprintf(srate,   "-r%d", refresh_rate);
        if (execlp("vscreen", "vscreen", swidth,
                                         sheight,
                                         sscale,
                                         skey,
                                         sLEDs,
                                         (char*)NULL) < 0)
            {
            perror("caller: ERROR - cannot start screen.");
            exit(1);
            }
    }
    else {
        /* ----------- the caller is the parent process ----------- */
        /* --- write to the frame store from the parent process --- */
        /* wait until the screen finishes setting up the shared buffer */
        /* the screen sends a SIGCONT signal to "wake up" the caller   */
        pause();

//printf("Off we go!\n");

        frame_sz = frame_nc * frame_width * frame_height;

        /* Attach to the shared memory buffer that is used as frame store */
        shm_sz = frame_sz + 2;
        shm = setup_shm(&shmid, (key_t)SHM_KEY, shm_sz);
                                 /* Segment ID agreed with screen program */

        /* setup the handshake pointer in shared memory */
        hndshk = &shm[frame_sz];

        /* setup the LED pointer in shared memory */
        ledshm = &shm[frame_sz + 1];

        /* allocate pix buffer */
        pixbuf = (char *) malloc(frame_width*frame_height*frame_nc*sizeof(char *));

        while (1) {
            /* request new image */
            sleep(2);
            *hndshk = HNDSHK_IMG_REQ;

            /* wait for new image in buffer */
            while((*hndshk & HNDSHK_IMG_ACK) == 0) sleep(0.5);

            /* put some "interesting" content into the memory */
            draw_picture(shm, hndshk, ledshm);
        }

        /* release the shared memory buffer */
        release_shm(shm);
        /* close the screen */
        kill(scrPid, SIGTERM);
        waitpid(scrPid, &status, 0);
        /* and terminate */
        exit(0);
    }
}

/*============================================================================*/
